<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index()
    {
       return response()->json(
            User::select('id', 'email', 'password')->get(),
            200,
            ['Content-Type' => 'application/json; charset=utf-8'],
            JSON_UNESCAPED_UNICODE
        );
        return response()->json([
        'users' => User::all()
    ]);
    }
}
